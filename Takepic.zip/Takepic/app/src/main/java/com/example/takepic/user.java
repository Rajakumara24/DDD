package com.example.takepic;

public class user {
    String assemblyConstituency,chiefEngineer;
    long telephone;

    public user(){

    }

    public user(String assemblyConstituency,String chiefEngineer,long telephone){
        this.assemblyConstituency=assemblyConstituency;
        this.chiefEngineer=chiefEngineer;
        this.telephone=telephone;
    }

    public String getsetAssemblyConstituency(){
        return assemblyConstituency;
    }
    public void setAssemblyConstituency(String assemblyConstituency){
        this.assemblyConstituency=assemblyConstituency;
    }
    public String getChiefEngineer(){
        return chiefEngineer;
    }
    public void setChiefEngineer(String chiefEngineer){
        this.chiefEngineer=chiefEngineer;
    }
    public long getTelephone(){
        return telephone;
    }
    public void setTelephone(long telephone){
        this.telephone=telephone;
    }
}
